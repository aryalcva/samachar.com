<?php
class Admin1 extends CI_Controller{
	public function index(){
		$this->load->view('admin/login');
	}
}
?>