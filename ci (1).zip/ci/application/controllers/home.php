<?php
class Home extends CI_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->model('newsmodel');
	}
	public function index(){
		$data['news'] = $this->newsmodel->getAllNews();
		$this->load->view('home',$data);
	}
}
?>