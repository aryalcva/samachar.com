<?php
class Ghar extends CI_Controller{
	
	public function __construct(){
		parent::__construct();
		$this->load->model('gharmodel');
	}
	public function index(){
		
		$data['user'] = $this->gharmodel->getAllUser();
		$this->load->view('ghar',$data);
	}
	public function adduser(){
		$this->load->view('admin/adduser');
	}
	
	public function saveUser(){
		$first_name = $this->input->post('first_name');
		$last_name = $this->input->post('last_name');
		$email = $this->input->post('email');
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$data = array(
		'first_name' => $first_name,
		'last_name' => $last_name,
		'email' => $email,
		'user' => $username,
		'password' => $password
		);
		
		$result = $this->gharmodel->save($data);
		if($result){
			redirect('ghar');
		}else{
			redirect('ghar');
		}
	}
	
	public function edituser($id){
		
		$data['user'] = $this->gharmodel->getRequiredUser($id);
		$this->load->view('admin/edituser',$data);
	}
	
	public function updateuser(){
		$id = $this->input->post('userid');
		$first_name = $this->input->post('first_name');
		$last_name = $this->input->post('last_name');
		$email = $this->input->post('email');
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$data = array(
		'first_name' => $first_name,
		'last_name' => $last_name,
		'email' => $email,
		'user' => $username,
		'password' => $password
		);
		
		$result = $this->gharmodel->update($data,$id);
		if($result){
			redirect('ghar');
		}else{
			redirect('ghar');
		}
	}
	
	public function deleteuser($id){
	 
	 $result = $this->gharmodel->delete($id);
	 if($result){
		 redirect('ghar');
	 }else{
		 redirect('ghar');
	 }
	}
	
}
?>