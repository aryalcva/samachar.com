<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>News Website Layout - free CSS template</title>
<meta name="keywords" content="News Layout, free css template, free website, CSS, HTML" />
<meta name="description" content="News Website Layout - free HTML CSS template provided by templatemo.com" />
<link href="<?php echo base_url(); ?>assets/templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/tabcontent.css" />
<script type="text/javascript" src="<?php echo base_url(); ?>assets/tabcontent.js">
/***********************************************
* Tab Content script v2.2- © Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
***********************************************/
</script>
<!--  HTML CSS Template Designed by w w w . t e m p l a t e m o . c o m  --> 
</head>
<body>
<div id="templatemo_container">

	<div id="templatemo_top_panel">
        <div id="templatemo_sitetitle">
            Hamro Samachar
        </div>
        
        
    </div> <!-- end of top panel -->
    
    <div id="templatemo_menu">
        <ul>
            <li><a href="index.html"  class="current">Home</a></li>
            <li><a href="#">Daily News</a></li>
            <li><a href="#">Sports</a></li>
            <li><a href="#">Business</a></li>  
            <li><a href="#">Politics</a></li> 
            <li><a href="#">Entertainment</a></li>                     
            <li><a href="#">Technology &amp; Science</a></li>            
        </ul> 
	</div>
    
	<div id="templatemo_content">

    	<div id="templatemo_main_leftcol">
        	
        	
            <div class="templatemo_leftcol_subcol">
            <div class="regular_section" style="background-color:#CCC">
                  <br />
                  <marquee>
                  <h2 style="color:#C00">Lamela tweet all but confirms Soldado's Tottenham exit <span style="color:#090"><b>|</b></span> Schweinsteiger expects to be fully fit by next week <span style="color:#090"><b>|</b></span> Liverpool won't mind winning ugly, says midfielder Lallana</h2>
                  </marquee>
            </div>
            <?php
			foreach($news as $n){
			?>
				<div class="regular_section">
					<div class="newsbox"><img src="<?php echo base_url(); ?>assets/img/<?php echo $n['image']; ?>" alt="image" height="100px" width="100px" /><span class="newstitle"><?php echo $n['news_title']; ?></span><br />
                        <p>
                        <?php echo substr($n['news_description'],0,250); ?>  <a href="#">full story</a></p>
				  	</div>
                        <a href="#"><?php echo $n['news_date']; ?></a>
                </div>
                <?php
			}
				?>
                
            </div>
            
            <div class="tab_section" style="display:none;">
               
				
                <div class="tabcontent_section">
                    <div id="health" class="tabcontent">
                        <div class="topnews">
                            <img src="<?php echo base_url();?>assets/images/templatemo_image_08.jpg" alt="image" />
                            <h4>Health News</h4>
                            <p>
                            Nunc quis sem nec tincidunt. Lorem ipsum dolor sit amet, adipiscing elit. Duis vitae velit sed dui malesuada dignissim. <a href="#">Full Story</a>
                            </p>
                        </div>
                        <div class="newslist">
                            
                            <a href="#">Read All Latest News</a>
                        </div>
			    	</div>
    
                    
				</div>

			<script type="text/javascript">
            
            var countries=new ddtabcontent("countrytabs")
            countries.setpersist(true)
            countries.setselectedClassTarget("link") //"link" or "linkparent"
            countries.init()
            
            </script>
            <!-- end -->

            </div>
    	</div> <!-- end of left column -->
        
        <div id="templatemo_main_rightcol">
        	<div class="templatemo_rcol_sectionwithborder">
            	<div id="templatemo_video_section">
                    <img src="<?php echo base_url(); ?>assets/images/add1.jpg" />
				</div>
            </div>
            
            <div class="templatemo_rcol_sectionwithborder">
            	<img src="<?php echo base_url(); ?>assets/images/add2.gif" width="350px;" height="200px;" />
            </div> 
            
            <div class="templatemo_rcol_sectionwithborder">
            	<img src="<?php echo base_url(); ?>assets/images/add3.gif" width="350px;" height="200px;" />                                                     
            </div> 
            
            <div class="templatemo_rcol_sectionwithborder">
            	<div id="templatemo_poll_section">
                    <h2>Poll</h2>
                    <img src="images/templatemo_image_08.jpg" alt="image" />
                    <p>
                    Lorem ipsum nunc quis sem dolor sit amet, consectetuer adipiscing elit. Nunc quis sem nec tellus blandit tincidunt.</p>
                <input type="radio" name="poll" value="yes" checked="checked" />Yes <br />
                    <input type="radio" name="poll" value="no" />No <br /><br />
                    <input class="button" type="submit" name="Submit" value="Vote" /> <a href="#">Viwe Result</a>
				</div>
            </div>
        </div>
    </div>
    
    <div id="templatemo_footer">
    	<div class="footer_leftcol">
	        Copyright © 2048 <a href="#"><strong>Your Company Name</strong></a><br />
			<a href="http://www.iwebsitetemplate.com" target="_parent">Website Templates</a> by <a href="http://www.templatemo.com" target="_parent">Free CSS Templates</a><br /><br />
            <p>Lorem ipsum nunc quis sem dolor sit amet, consectetuer adipiscing elit. Nunc quis sem nec tellus blandit tincidunt. Duis mollis aliquet ligula.</p>
        </div>
        <div class="footer_rightcol">
        	<div class="footer_subcol">
				<a href="#">Mainpage</a><br />
              	<a href="#">Company</a><br />
                <a href="#">Advertise</a><br />
                <a href="#">Feedback</a><br />
			</div>
            <div class="footer_subcol">
				<a href="#">English</a><br />
				<a href="#">Japanese</a><br />
				<a href="#">Chinese</a><br />
				<a href="#">German</a><br />
                <a href="#">French</a>
                </div>
            <div class="footer_subcol">
				<a href="#">Terms</a><br />
                <a href="#">Privacy</a><br />
                <a href="#">Sitemap</a><br />
                <a href="#">Contact</a><br />
                <a href="#">Help</a>
			</div>
        </div>
        
    </div> <!-- end of footer -->
<!--  HTML CSS Template Designed by w w w . t e m p l a t e m o . c o m  --> 
</div>
</body>
</html>