<a href="<?php echo base_url(); ?>index.php/ghar/adduser">Add User</a>
<br />
<table border="1">
<tr>
<td>First Name</td>
<td>Last Name</td>
<td>Email</td>
<td>Username</td>
<td>Edit</td>
<td>Delete</td>
</tr>
<?php
if($user){
	foreach($user as $u){
?>
<tr>
<td><?php echo $u['first_name']; ?></td>
<td><?php echo $u['last_name']; ?></td>
<td><?php echo $u['email']; ?></td>
<td><?php echo $u['user']; ?></td>
<td><a href="<?php echo base_url(); ?>index.php/ghar/edituser/<?php echo $u['id']; ?>">Edit</a></td>
<td><a href="<?php echo base_url(); ?>index.php/ghar/deleteuser/<?php echo $u['id']; ?>">Delete</a></td>
</tr>
<?php
	}
}
?>
</table>