<?php $this->load->view('admin/header'); ?>
<?php $this->load->view('admin/sidebar');?>
<div id="page-wrapper">
    <div id="page-inner">


        <div class="row">
            <div class="col-md-12">
                <h1 class="page-header">
                    News <small>List Of News</small>
                </h1>
            </div>
        </div>
        <!-- /. ROW  -->

        <div class="row">
            <div>
                <br />
                <a href="<?php echo base_url(); ?>index.php/news/addnews" class="btn btn-primary">Add News</a>
                <b style="color:green">
                    <?php
                    if($this->session->userdata('succ_msg')){
                        echo $this->session->userdata('succ_msg');
                        $this->session->unset_userdata('succ_msg');
                    }
                    ?>
                </b>
                <br /> <br />

                <table class="table table-bordered">
                   
                    <thead>
                    <th>S.N</th>
                    <th>Category</th>
                    <th>Title</th>
                    <th>Image</th>
                    <th>Edit</th>
                    <th>Delete</th>
                    </thead>
                    <?php
                    $i = 0;
					if($news){
  foreach($news as $new)
  {
                        $i++;
                        ?>
                        <tr>
                            <td><?php echo $i ;?></td>
                            <td><?php echo $new['name']; ?></td>
                            <td><?php echo $new['news_title'];?></td>
                            <td><img src="<?php echo base_url();?>/assets/img/<?php echo $new['image'];?>" width="50" height="50"> </td>
                            <td><a href="<?php echo base_url() ?>index.php/news/editnews/<?php echo $new['news_id']; ?>" class="btn btn-info">Edit</a></td>
                            <td><a href="<?php echo base_url(); ?>index.php/news/deleteNews/<?php echo $new['news_id']; ?>" class="btn btn-danger">Delete</a></td>
                        </tr>
                    <?php
                    }
					}
                    ?>
                </table>
            </div>
        </div>
        <?php $this->load->view('admin/footer'); ?>