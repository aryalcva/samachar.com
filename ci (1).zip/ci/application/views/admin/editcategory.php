<?php $this->load->view('admin/header'); ?>
<?php $this->load->view('admin/sidebar');?>
        <div id="page-wrapper">
            <div id="page-inner">


                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Category Edit<small></small>
                        </h1>
                    </div>
                </div>
                <!-- /. ROW  -->

               <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Update Category information
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form method="post" action="<?php echo base_url(); ?>index.php/category/updateCategory">
                                    <input type="hidden" name="id" value="<?php echo $category['id']; ?>" />
                                        <div class="form-group">
                                            <label>Category Name</label>
                                            <input type="text" name="category_name" value="<?php echo $category['name']; ?>" class="form-control" placeholder="First Name">
                                            
                                        </div>
                                       
                                        <input type="submit" class="btn btn-success" value="Save Category" />
                                        
                                    </form>
                                </div>
                                
                                    
                                    
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                            </div>
         <?php $this->load->view('admin/footer'); ?>       