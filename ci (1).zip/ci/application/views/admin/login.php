<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<body>
<b style="color:red">
<?php
if($this->session->userdata('error_msg')){
	echo $this->session->userdata('error_msg');
	$this->session->unset_userdata('error_msg');
}
?>
</b>
<form method="post" action="<?php echo base_url();?>index.php/admin/login">
<pre>
<input type="text" name="username" required="required" />
<input type="password" name="password" required="required" />
<input type="submit" name="login" value="LogIn" />
</pre>
</form>
</body>
</html>