<?php $this->load->view('admin/header'); ?>
<?php $this->load->view('admin/sidebar');?>
        <div id="page-wrapper">
            <div id="page-inner">


                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            User <small>List Of user</small>
                        </h1>
                    </div>
                </div>
                <!-- /. ROW  -->

                <div class="row">
                <div>
               <br />
               <a href="<?php echo base_url(); ?>index.php/user/add" class="btn btn-primary">Add User</a>
               <b style="color:green">
               <?php
			   if($this->session->userdata('succ_msg')){
				   echo $this->session->userdata('succ_msg');
				  $this->session->unset_userdata('succ_msg');
			   }
			   ?>
               </b>
               <hr />
               <form method="post" action="<?php echo base_url(); ?>index.php/user/index">
               <input type="text" name="username" />
               <input type="submit" name="search" value="Search" class="btn btn-warning" />
               </form>
               <br /> <br />
               
<table class="table table-bordered">
	<thead>
    	<th>S.N</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>User</th>
        <th>Email</th>
        <th>Edit</th>
        <th>Delete</th>
    </thead>
    <?php
	$i = 0;
	if($user){
	foreach($user as $u){
		$i++;
	?>
    <tr>
    	<td><?php echo $i ;?></td>
        <td><?php echo $u['first_name']; ?></td>
        <td><?php echo $u['last_name'];?></td>
        <td><?php echo $u['user'];?></td>
        <td><?php echo $u['email'];?></td>
        <td><a href="<?php echo base_url() ?>index.php/user/edituser/<?php echo $u['id']; ?>" class="btn btn-info">Edit</a></td>
        <td><a href="<?php echo base_url(); ?>index.php/user/deleteuser/<?php echo $u['id']; ?>" class="btn btn-danger">Delete</a></td>
    </tr>
    <?php
		}
	}
	?>
</table>
</div>
</div>
         <?php $this->load->view('admin/footer'); ?>       