<?php $this->load->view('admin/header'); ?>
<?php $this->load->view('admin/sidebar');?>
        <div id="page-wrapper">
            <div id="page-inner">


                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Category <small>List Of category</small>
                        </h1>
                    </div>
                </div>
                <!-- /. ROW  -->

                <div class="row">
                <div>
               <br />
               <a href="<?php echo base_url(); ?>index.php/category/add" class="btn btn-primary">Add Category</a>
               <b style="color:green">
               <?php
			   if($this->session->userdata('succ_msg')){
				   echo $this->session->userdata('succ_msg');
				  $this->session->unset_userdata('succ_msg');
			   }
			   ?>
               </b>
               <br /> <br />
               
<table class="table table-bordered">
	<thead>
    	<th>S.N</th>
        <th>Category Name</th>
        <th>Edit</th>
        <th>Delete</th>
    </thead>
    <?php
	$i = 0;
	foreach($category as $c){
		$i++;
	?>
    <tr>
    	<td><?php echo $i ;?></td>
        <td><?php echo $c['name']; ?></td>
        <td><a href="<?php echo base_url(); ?>index.php/category/editcategory/<?php echo $c['id']; ?>" class="btn btn-info">Edit</a></td>
        <td><a href="<?php echo base_url(); ?>index.php/category/deletecategory/<?php echo $c['id'];?>" class="btn btn-danger">Delete</a></td>
    </tr>
    <?php
		}
	?>
</table>
</div>
</div>
         <?php $this->load->view('admin/footer'); ?>       