        <!--/. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                    <li>
                        <a class="active-menu" href="index.html"><i class="fa fa-dashboard"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="<?php echo base_url(); ?>index.php/user"><i class="fa fa-dashboard"></i> User</a>
                    </li>
                    <li>
                        <a href="<?php echo base_url(); ?>index.php/category"><i class="fa fa-dashboard"></i> Category</a>
                    </li>
                    <li>
                        <a href="<?php echo base_url(); ?>index.php/news"><i class="fa fa-dashboard"></i> News</a>
                    </li>
                    <li>
                        <a href="<?php echo base_url(); ?>index.php/admin/logout"><i class="fa fa-dashboard"></i> Logout</a>
                    </li>
                </ul>

            </div>

        </nav>