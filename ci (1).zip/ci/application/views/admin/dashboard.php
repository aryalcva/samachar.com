<?php $this->load->view('admin/header'); ?>
<?php $this->load->view('admin/sidebar');?>
        <div id="page-wrapper">
            <div id="page-inner">


                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Dashboard <small>Summary of your App</small>
                        </h1>
                    </div>
                </div>
                <!-- /. ROW  -->

                <div class="row">
                   
                </div>
         <?php $this->load->view('admin/footer'); ?>       