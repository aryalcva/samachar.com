<?php
class newsmodel extends CI_Model{
    public function getAllNews(){
        $this->db->select("*");
        $this->db->from("tbl_news");
		$this->db->join("tbl_category","tbl_category.id=tbl_news.category_id");
        $query = $this->db->get();
        if($query->num_rows() > 0){
            return $query->result_array();
        }else{
            return false;
        }
    }

    public function getRequiredNews($id = null){
        $this->db->select("*");
        $this->db->from("tbl_news");
        $this->db->where("news_id",$id);
        $query = $this->db->get();
        if($query->num_rows() > 0){
            return $query->result_array()[0];
        }else{
            return false;
        }
    }

    public function saveNews($data = null){
        if($this->db->insert("tbl_news",$data)){
            return true;
        }else{
            return false;
        }
    }

    public function updateNews($data = null, $id = null){
        $this->db->where("news_id",$id);
        if($this->db->update("tbl_news",$data)){
            return true;
        }else{
            return false;
        }
    }

    public function deleteNews($id = null){
        $this->db->where("news_id",$id);
        if($this->db->delete("tbl_news")){
            return true;
        }else{
            return false;
        }
    }

}